package com.dowon.ai_dire_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiDireServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
